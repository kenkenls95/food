create view order_product as
select `od`.`order_detail_id` AS `order_detail_id`,
       `od`.`order_id`        AS `order_id`,
       `od`.`food_id`         AS `food_id`,
       `od`.`quantity`        AS `quantity`,
       `od`.`price`           AS `price`,
       `p`.`name`             AS `name`,
       `d`.`path`             AS `path`
from ((`food`.`order_detail` `od` join `food`.`product` `p` on (`od`.`food_id` = `p`.`product_id`))
         join `food`.`document` `d` on (`d`.`parent_id` = `p`.`product_id`))
where `p`.`is_active` = 1
  and `d`.`type` = 1;

