create view payment_detail as
select `p`.`payment_id`                                                              AS `payment_id`,
       `p`.`order_id`                                                                AS `order_id`,
       `b`.`name`                                                                    AS `name`,
       `p`.`price`                                                                   AS `price`,
       `p`.`extra`                                                                   AS `extra`,
       case
           when `p`.`status` is null then 'Chưa Thanh Toán'
           when `p`.`status` = 1 then 'Đã Thanh Toán'
           when `p`.`status` = 2 then 'Nợ Xấu' end                                   AS `status`,
       `b`.`author`                                                                  AS `author`,
       case when `b`.`type` = 1 then 'Shipping' when `b`.`type` = 2 then 'Table' end AS `type`
from (`food`.`payment` `p`
         join `food`.`order_bill` `b` on (`b`.`order_id` = `p`.`order_id`));

